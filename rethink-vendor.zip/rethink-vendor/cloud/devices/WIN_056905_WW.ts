import TLVDevice from './tlv_device'
import { Device as Thinq2Device } from '../thinq2/device'
import { DeviceDiscovery, type Connection } from '../homeassistant'
import { type Metadata } from '../thinq'
import { allowExtendedType } from '@/util/casting'
import * as TLV from '@/util/tlv'
import HADevice from './base'

/**
 * LG Air Conditioner Model LW1823HRSM
 */
export default class Device extends TLVDevice {
    constructor(HA: Connection, thinq: Thinq2Device, meta: Metadata) {
        super(HA, thinq)
        const config: DeviceDiscovery = allowExtendedType({
            ...HADevice.config(meta),
            name: 'LG Air Conditioner',
            components: {
                climate: {
                    platform: 'climate',
                    unique_id: '$deviceid-climate',
                    name: null,
                    temperature_unit: 'C',
                    temp_step: 0.5,
                    precision: 0.5,
                    modes: ['off', 'cool', 'fan_only', 'heat'],
                    fan_modes: ['low', 'high'],
                    swing_modes: ['on', 'off'],
                },
            },
        })

        this.addField(config, {
            id: 0x1fd,
            name: 'current_temperature',
            comp: 'climate',
            state_topic: 'topic',
            writable: false,
            read_xform: (raw) => raw / 2,
        })

        this.addField(config, {
            id: 0x1fe,
            name: 'temperature',
            comp: 'climate',
            read_xform: (raw) => raw / 2,
            write_xform: (valStr) => {
                const val = Number(valStr)
                // set val to min: 61F, max: 86F
                const minCel = 16
                const maxCel = 30.0
                if (val < minCel) return minCel * 2
                if (val > maxCel) return maxCel * 2
                return Math.round(val * 2)
            },
            write_attach: [0x1f9, 0x1fa],
        })

        this.addField(config, {
            id: 0x1f7,
            name: 'power',
            comp: 'climate',
            readable: false,
            write_xform: (val) => (val === 'ON' ? 1 : 0),
            write_attach: (raw) => (raw ? [0x1f9] : []),
            read_xform: (raw) => (raw ? 'ON' : 'OFF'),
            read_callback: (val) => {
                // update 'mode' instead
                this.processKeyValue(0x1f9, this.raw_clip_state[0x1f9])
                return false
            },
        })

        this.addField(config, {
            id: 0x1f9,
            name: 'mode',
            comp: 'climate',
            read_xform: (raw) => {
                const modes2ha = [
                    'cool',
                    undefined,
                    'fan_only',
                    undefined,
                    'heat',
                    undefined,
                    undefined,
                    undefined,
                    undefined, // 'eco'
                ]
                if (this.raw_clip_state[0x1f7] === 0) return 'off'
                return modes2ha[raw]
            },
            write_xform: (val) => {
                const modes2clip: Record<string, number> = { cool: 0, fan_only: 2, heat: 4, dry: 8 }
                if (val === 'off') {
                    // Call function power (0x1f7) with value OFF
                    this.setProperty('power', 'OFF')
                } else {
                    this.setProperty('power', 'ON')
                }
                return modes2clip[val]
            },
            write_attach: [0x1f7, 0x1fa, 0x1fe, 0x322],
        })

        this.addField(config, {
            id: 0x1fa,
            name: 'fan_mode',
            comp: 'climate',
            read_xform: (raw) => {
                const modes2ha: Record<string, string> = { '2': 'low', '6': 'high' }
                return modes2ha[raw]
            },
            write_xform: (val) => {
                const modes2clip: Record<string, number> = {
                    low: 2,
                    high: 6,
                }
                return modes2clip[val]
            },
            write_attach: [0x1f9, 0x1fe],
        })

        this.addField(config, {
            id: 0x322,
            name: 'swing_mode',
            comp: 'climate',
            read_xform: (raw) => {
                const modes2ha: Record<string, string> = { '0': 'off', '100': 'on' }
                return modes2ha[raw]
            },
            write_xform: (val) => {
                const modes2clip: Record<string, number> = {
                    off: 0,
                    on: 100,
                }
                return modes2clip[val]
            },
            write_attach: [0x1f9, 0x1fa],
        })

        this.setConfig(config)
    }

    isCapsResponse(tlvArray: TLV.TLV[]) {
        /* eeprom checksum */
        return tlvArray.some(({ t, v }) => t === 0x2da)
    }

    isValuesResponse(tlvArray: TLV.TLV[]) {
        /* power */
        return tlvArray.length >= 10 && tlvArray.some(({ t, v }) => t === 0x1f7)
    }
}
