import {
    Client as ThinqClient,
    Device as ClientDevice,
    Environment,
    signInUrl,
    Thinq1Device,
    Thinq2Device,
} from './thinqApi'
import { AnyDevice, DeviceManager } from '../cloud/devmgr'
import * as OAuth2 from './oauth2'
import { BridgeState } from './state'
import { Connection as Thinq1Connection } from './thinq1connection'
import { Connection as Thinq2Connection } from './thinq2connection'
import { Device as T1Downstream } from '@/cloud/thinq1/device'
import { Device as T2Downstream } from '@/cloud/thinq2/device'
import { TypedEmitter } from 'tiny-typed-emitter'

type StatusCallback = (status: string) => void

const RECONNECT_PERIOD = 5000

/**
 * Decides how an appliance should be registered before it can be bridged.
 *
 * An appliance that is already in this home keeps its registration and its name. Deleting and
 * re-adding it would rename it to "Rethink xxxxxxxx", announce the removal to every app on the
 * account, and leave the appliance unable to reach LG on its own. Bridging needs the credentials
 * from pair(), not a fresh registration.
 */
export function registrationPlan(homeDevices: { deviceId: string; alias: string }[], deviceId: string) {
    const registered = homeDevices.find((dev) => dev.deviceId === deviceId)
    return {
        removeFirst: !registered,
        alias: registered?.alias ?? `Rethink ${deviceId.substring(0, 8)}`,
    }
}

class BridgedDevice {
    // upstream - our connection to the ThinQ cloud
    // downstream - the physical device
    constructor(
        readonly upstream: ClientDevice,
        readonly downstream: AnyDevice,
    ) {
        // we create the functions at runtime so that they have unique identities that can be removed with removeListener
        this.onDownstreamData = (packet: Buffer) => this.connection?.send(packet)
        this.onDownstreamClose = () => this.destroy()

        if (this.upstream.platformType !== this.downstream.platform) {
            console.warn("Bridge device types don't match")
            return
        }

        downstream.on('data', this.onDownstreamData)
        downstream.on('close', this.onDownstreamClose)

        this.reconnectNow()
    }

    onDownstreamData: (packet: Buffer) => void
    onDownstreamClose: () => void

    connection: Thinq1Connection | Thinq2Connection | undefined

    reconnectNow() {
        const U = this.upstream
        const D = this.downstream
        if (U instanceof Thinq1Device && D instanceof T1Downstream) {
            this.connection = new Thinq1Connection(U)
            // feed the initial state to the connection
            if (D.lastReport) this.connection.send(D.lastReport)

            this.connection.on('data', (payload) => D.send(payload))
        } else if (U instanceof Thinq2Device && D instanceof T2Downstream) {
            // Forward the physical device's real deploy appInfo/platformInfo so the upstream
            // preDeploy reports its true protocolVer/softVer/etc. instead of placeholders.
            this.connection = new Thinq2Connection(U, D.deployAppInfo, D.deployPlatformInfo)
            this.connection.on('data', (payload) => D.send_packet(payload))
        } else {
            console.warn("Can't connect bridge")
            return
        }

        this.connection.on('close', () => this.disconnect())
        this.connection.on('error', console.log)
    }

    reconnectTimeout: NodeJS.Timeout | undefined

    disconnect() {
        if (this.connection) {
            this.connection.destroy()
            this.connection = undefined
            clearTimeout(this.reconnectTimeout)
            this.reconnectTimeout = setTimeout(() => this.reconnectNow(), RECONNECT_PERIOD)
        }
    }

    destroy() {
        if (this.connection) {
            this.connection.destroy()
            this.connection = undefined
        }
        this.downstream.removeListener('data', this.onDownstreamData)
        this.downstream.removeListener('close', this.onDownstreamClose)
        clearTimeout(this.reconnectTimeout)
        this.reconnectTimeout = undefined
    }
}

type BridgeEvents = {
    loggedIn: () => void
    loggedOut: () => void
    started: (id: string) => void
    stopped: (id: string) => void
}

export class Bridge extends TypedEmitter<BridgeEvents> {
    bridgedDevices = new Map<string, BridgedDevice>()

    constructor(
        readonly state: BridgeState,
        readonly manager: DeviceManager,
    ) {
        super()
        this.manager.on('newDevice', this.#start.bind(this))
        this.manager.on('dropDevice', this.#stop.bind(this))
        Object.values(this.manager.allDevices).forEach(this.#start.bind(this))
    }

    #start(dev: AnyDevice) {
        const clientDevice = this.loadSavedDevice(dev)
        if (!clientDevice) return

        const bridged = new BridgedDevice(clientDevice, dev)
        this.bridgedDevices.set(dev.id, bridged)
        this.emit('started', dev.id)
    }

    #stop(id: string) {
        const bridged = this.bridgedDevices.get(id)
        if (bridged) {
            this.bridgedDevices.delete(id)
            this.emit('stopped', id)
            bridged.destroy()
        }
    }

    status(id: string) {
        const dev = this.manager.allDevices[id]
        if (!dev) return undefined

        if (this.bridgedDevices.has(id)) return true

        return false
    }

    async enable(id: string, devType?: string, statusCallback?: StatusCallback) {
        if (!this.isLoggedIn()) return false

        if (this.bridgedDevices.has(id)) return true

        const dev = this.manager.allDevices[id]
        if (!dev) return false

        const clientDevice = await this.register(dev, devType, statusCallback)
        if (!clientDevice) return false

        const bridged = new BridgedDevice(clientDevice, dev)
        this.bridgedDevices.set(dev.id, bridged)
        this.emit('started', dev.id)
        return true
    }

    disable(id: string) {
        this.state.setDeviceState(id, undefined)
        this.#stop(id)
    }

    isLoggedIn() {
        return !!this.state.getCredentials()
    }

    async beginLogin(env: Environment): Promise<URL> {
        const client = new ThinqClient(env)
        const base = await client.getUrls()
        return signInUrl(base.webUrl, env.countryCode)
    }

    async completeLogin(env: Environment, url: URL) {
        const client = new ThinqClient(env)
        const base = await client.getUrls()
        const code = url.searchParams.get('code')
        if (!code) return false

        try {
            const token = await OAuth2.fromCode(base.authUrl, code)
            this.state.setCredentials({
                env,
                refreshToken: token.refreshToken,
            })
            this.emit('loggedIn')
            return true
        } catch (err) {
            return false
        }
    }

    logout() {
        this.state.setCredentials(undefined)
        // FIXME? drop all devices
        this.emit('loggedOut')
    }

    async register(device: AnyDevice, deviceType?: string, statusCallback?: StatusCallback) {
        if (!statusCallback) statusCallback = () => {}

        const creds = this.state.getCredentials()
        if (!creds) throw new Error('Not logged in')

        if (!deviceType) deviceType = device.meta.deviceType

        if (!deviceType) throw new Error('Device type must be specified')

        const client = new ThinqClient(creds.env)
        await client.auth(creds.refreshToken)

        const { removeFirst, alias } = registrationPlan(await client.listDevices(), device.id)

        if (removeFirst) {
            statusCallback('Removing device from home')
            await client.removeDevice(device.id)
        }

        let clientDevice: Thinq1Device | Thinq2Device

        if (device.platform === 'thinq1') {
            const gateway = await client.gateway
            const state = {
                httpServer: gateway.thinq1Uri.replace(/\/api$/, ''),
                rtiServer: gateway.rtiUri,
            }

            clientDevice = new Thinq1Device(device.id, device.meta, state)
            statusCallback('Adding device to home')

            await client.addDevice(clientDevice, alias, deviceType)
        } else if (device.platform === 'thinq2') {
            statusCallback('Fetching otp key')
            const otp = await client.prepareNewT2Device()

            const t2 = new Thinq2Device(device.id, device.meta)
            clientDevice = t2

            statusCallback('Registering new device')
            let ciphertext
            try {
                ciphertext = await t2.pair(client.env, otp)
            } catch (err) {
                statusCallback('Pairing failed. Make sure that common.lgthinq.com is not redirected')
                throw err
            }

            statusCallback('Adding device to home')
            await client.addDevice(clientDevice, alias, deviceType, ciphertext)

            // Persist the physical device's real deploy info alongside the topics, so the
            // upstream preDeploy can report the true protocolVer/softVer/etc. even after a
            // restart, before the device has re-deployed to us.
            if (t2.state && device instanceof T2Downstream) {
                t2.state.deployAppInfo = device.deployAppInfo
                t2.state.deployPlatformInfo = device.deployPlatformInfo
            }
        } else {
            throw new Error('Unknown device platform')
        }

        statusCallback('Device registered successfully')

        this.state.setDeviceState(device.id, clientDevice.state)
        return clientDevice
    }

    loadSavedDevice(device: AnyDevice) {
        const state = this.state.getDeviceState(device.id)
        if (state) {
            if ('rtiServer' in state) {
                // thinq1
                return new Thinq1Device(device.id, device.meta, state)
            } else if ('mqttServer' in state) {
                // thinq2
                return new Thinq2Device(device.id, device.meta, state)
            }
        }

        return undefined
    }
}
