# rethink-vendor — 출처 및 라이선스 안내

이 폴더는 [anszom/rethink](https://github.com/anszom/rethink)를 그대로 가져온 벤더링(vendored)
소스입니다. 매 빌드마다 외부 저장소/PR을 실시간으로 받아오는 대신, 특정 시점의 코드를
이 저장소 안에 고정해두고 우리가 직접 유지보수하기 위한 것입니다.

## 출처

- 원본 저장소: https://github.com/anszom/rethink
- 가져온 지점: [PR #107](https://github.com/anszom/rethink/pull/107) (병합되지 않은 상태,
  2026-07-31 기준) — SNI별 인증서 발급, bridge 활성화 시 기존 LG 등록 유지,
  `advertise_requested_host` 옵션이 이 PR에 포함되어 있습니다.
- 커밋: `c40650fda4797788d90ab5f7ed59176090a1b054`
  ("bridge: forward the device's real deploy appInfo/platformInfo upstream")
- 가져온 날짜: 2026-07-31

## 라이선스

rethink는 **GPL-2.0**입니다. 원본 라이선스 전문은 `COPYING` 파일에 그대로 포함되어 있습니다.
이 폴더 안의 코드를 수정한다면, 그 수정 사항 역시 GPL-2.0 조건을 따라야 합니다
(소스 공개 의무 등). 저작권은 원 저자([anszom](https://github.com/anszom))에게 있습니다.

## 이 소스를 갱신하려면

1. PR #107이 병합되었는지, 또는 원본에 우리가 원하는 최신 수정사항이 반영됐는지 확인
2. 아래 명령으로 원하는 지점을 다시 받아옴:
   ```
   git clone https://github.com/anszom/rethink /tmp/rethink-fetch
   cd /tmp/rethink-fetch
   git fetch origin refs/pull/107/head   # 또는 병합됐다면: git fetch origin master
   git checkout FETCH_HEAD
   ```
3. `.git`을 제외한 전체를 이 폴더(`rethink-vendor/`)에 덮어씀
4. 이 파일의 "가져온 지점"/"커밋"/"가져온 날짜"를 갱신
5. `LGLocalManager` 쪽에서 우리가 직접 패치한 부분이 있다면(예: 포트 기본값 조정 등)
   덮어쓰기 전에 diff를 떠서 재적용

## 우리가 이 위에 얹은 것 (LGLocalManager 쪽 코드, GPL 대상 아님)

`rethink-vendor/` 자체는 원본을 그대로 옮긴 것이고, 아무 수정도 하지 않았습니다.
ARP 스푸핑, WinDivert 리다이렉트, devices.json 관리, 트레이 앱, 자동 업데이트 등은
전부 `app/` 아래에 별도 코드로 존재하며 rethink 소스를 서브프로세스로 실행할 뿐,
GPL 코드를 링크하거나 파생하지 않습니다.
